package com.example.Spring.Bookzy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBookzyApplicationTests {

	@Test
	void contextLoads() {
	}

}
