package com.example.Spring.Bookzy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBookzyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBookzyApplication.class, args);
	}

}
